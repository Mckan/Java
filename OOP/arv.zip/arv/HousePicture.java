/**
 * A picture of a house
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HousePicture
{
	// instance variables - replace the example below with your own
	private Square wall;
	private Square window;
	private Triangle roof;
	private Circle sun;

	/**
	 * Constructor for objects of class HousPicture
	 */
	public HousePicture()
	{
        wall = new Square(60,130,"red",true,90);
        window = new Square(80,150,"black",true,30);
        roof = new Triangle(105,60,"green",true,120,70);
        sun = new Circle(200,50,"yellow",true,60);
        
        draw();
	}
	
	public void draw()
	{
	    wall.draw();
        window.draw();
        roof.draw();
        sun.draw();
	}
	
     public void erase()
	{
	    wall.erase();
        window.erase();
        roof.erase();
        sun.erase();
    }
}
