import java.awt.*;
import java.awt.geom.*;

/**
 * A circle that can be manipulated and that draws itself on a canvas.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 1.0  (15 July 2000)
 */

public class Circle
{
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;
    private int diameter;
    
    /**
     * Create a new circle at default position with default color.
     */
    public Circle( int xPosition, int yPosition, String color, boolean isVisible, int diameter)
    {
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.color = new String(color);
        this.isVisible = isVisible;
        this.diameter = diameter;
    }

    /**
     * Draw the circle with current specifications on screen.
     */
    public void draw()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color, new Ellipse2D.Double(xPosition, yPosition, 
                                                          diameter, diameter));
            canvas.wait(10);
        }
    }
    
    /**
     * Erase the picture from the screen.
     */
    protected void erase()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
    /**
     * Make this square visible. If it was already visible, do nothing.
     */
    public void makeVisible()
    {
        isVisible = true;
        draw();
    }
    
    /**
     * Make this square invisible. If it was already invisible, do nothing.
     */
    public void makeInvisible()
    {
        erase();
        isVisible = false;
    }

    /**
     * Move the figure by (deltaX,deltaY) pixels.
     */
    public void move(int deltaX, int deltaY)
    {
        erase();
        xPosition += deltaX;
        yPosition += deltaY;
        draw();
    }
    
    /**
     * Move the figure to position (x,y).
     */
    public void moveTo(int x, int y)
    {
        move(x-xPosition,y-yPosition);
    }

    /**
     * Change the color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor)
    {
        color = newColor;
        draw();
    }
    
   /**
     * Change the size proportionally according to scale factor.
     */
    public void resize(double scaleFactor)
    {
        erase();
        diameter *= scaleFactor;
        draw();
    }
}
