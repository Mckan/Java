/**
 * A picture of a house
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

// This will not compile until you have constructed class Group.
public class NewHousePicture {
    public static Group getPicture()
    {
        // ... to be completed
    }
}
