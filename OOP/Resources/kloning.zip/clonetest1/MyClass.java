import java.util.ArrayList;

/**
 * Objekt av typen MyClass kan kopieras med metoden clone (Version 1)
 * 
 * @author Uno Holmer
 * @version 2010-11-25
 */

public class MyClass implements Cloneable {
    // public visibility here for simplicity only
	public int anInt;
	public ArrayList<ListElement> aList;

	public MyClass() {
		anInt = 123;
		aList = new ArrayList<ListElement>();
		aList.add(new ListElement("text 1"));
	}

	// Grund kopiering av hela objektet
	public MyClass clone() {
	    try {
    	    return (MyClass)super.clone();
	    }
	    catch (CloneNotSupportedException e) {
	        throw new InternalError();
	    }
	}
}
