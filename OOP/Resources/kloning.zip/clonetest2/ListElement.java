public class ListElement implements Cloneable {
	public String value;

	public ListElement(String value) {
		this.value = value;
	}
	
    public ListElement clone() {
        try {
            return (ListElement)super.clone();
        }
        catch (CloneNotSupportedException e) {
            throw new InternalError();
        }
    }
}