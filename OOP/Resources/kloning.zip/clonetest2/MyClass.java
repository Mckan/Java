import java.util.ArrayList;

/**
 * Objekt av typen MyClass kan kopieras med metoden clone (Version 2)
 * 
 * @author Uno Holmer
 * @version 2010-11-25
 */

public class MyClass implements Cloneable {
    // public visibility here for simplicity only
	public int anInt;
	public ArrayList<ListElement> aList;

	public MyClass() {
		anInt = 123;
		aList = new ArrayList<ListElement>();
		aList.add(new ListElement("text 1"));
	}

	
	// Djup kopiering av listan, grund kopiering av listelementen
    @SuppressWarnings("unchecked")
	public MyClass clone() {
	    try {
    	    MyClass copy = (MyClass)super.clone();
    	    copy.aList = (ArrayList<ListElement>)aList.clone();  
    	    return copy;
        }
    	catch (CloneNotSupportedException e) {
    	    throw new InternalError();
	    }
	}
}
