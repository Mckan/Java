/**
 * Demonstrerar kloning av objekt
 * 
 * @author Uno Holmer
 * @version 2010-11-25
 */

public class Main {
    private MyClass a, b;
    
	public Main() {
         a = new MyClass();
         
         b = a.clone();
         b.anInt = 456;
         b.aList.get(0).value = "text 2";
         b.aList.add(new ListElement("text 3"));
	}
}
