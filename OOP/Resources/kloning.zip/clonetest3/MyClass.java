import java.util.ArrayList;
import java.util.List;
/**
 * Objekt av typen MyClass kan kopieras med metoden clone (Version 3)
 * 
 * @author Uno Holmer
 * @version 2010-11-25
 */

public class MyClass implements Cloneable {
    // public visibility here for simplicity only
	public int anInt;
	public ArrayList<ListElement> aList;

	public MyClass() 	{
		anInt = 123;
		aList = new ArrayList<ListElement>();
		aList.add(new ListElement("text 1"));
	}

    @SuppressWarnings("unchecked")
	// Djup kopiering av listan och listelementen
	public MyClass clone() {
	    try {
    	    MyClass copy = (MyClass)super.clone();   
    	    copy.aList = (ArrayList<ListElement>)aList.clone();
    	    // Djup kopiering av listelementen
    	    for ( int i = 0; i < aList.size(); i++ )
    	        copy.aList.set(i,(ListElement)aList.get(i).clone());
      
    	    return copy;
	    }
	    catch (CloneNotSupportedException e) {
	        throw new InternalError();
        }
	}
}
